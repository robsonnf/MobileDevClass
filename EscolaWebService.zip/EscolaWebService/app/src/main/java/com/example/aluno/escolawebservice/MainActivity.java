package com.example.aluno.escolawebservice;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;

public class MainActivity extends AppCompatActivity {
    AcessoRest rest;
    EditText retorno;
    EditText id;
    EditText nome;
    EditText telefone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        rest = new AcessoRest();

        retorno = findViewById(R.id.edtResultado);
        id = findViewById(R.id.edtID);
        nome = findViewById(R.id.edtNome);
        telefone = findViewById(R.id.edtTelefone);

    }

    public void listar(View view) {
        String url = "aluno/listar";
        String resposta = rest.chamadaGet(url, "GET");
        retorno.setText(resposta);
    }

    public void buscar(View view) {
        String url = "aluno/buscar/" + id.getText().toString();
        String resposta = rest.chamadaGet(url, "GET");
        retorno.setText(resposta);
    }

    public void excluir(View view) {
        String url = "aluno/excluir/" + id.getText().toString();
        String resposta = rest.chamadaGet(url, "DELETE");
        retorno.setText(resposta);
    }

    public void inserir(View view) {
        String url = "aluno/inserir";
        Aluno a = new Aluno();
        a.setNome(nome.getText().toString());
        a.setTelefone(telefone.getText().toString());

        Gson gson = new Gson();

        String sJson = gson.toJson(a);

        String resposta = rest.chamadaPost(url, sJson, "POST");

        retorno.setText(resposta);
    }
}
