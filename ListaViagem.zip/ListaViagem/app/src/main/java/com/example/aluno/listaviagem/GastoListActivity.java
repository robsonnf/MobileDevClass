package com.example.aluno.listaviagem;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

/**
 * Created by aluno on 21/03/2018.
 */

public class GastoListActivity extends ListActivity
        implements AdapterView.OnItemClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setListAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, listarGastos()));

        ListView listView = getListView();
        listView.setOnItemClickListener(this);
    }

    private List<String> listarGastos() {
        return Arrays.asList("Hospedagem R$ 300,00",
                            "Táxi Aeroporto - Hotel R$ 30,00",
                            "Almoço R$ 25,00");
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView,
                            View v, int position, long id) {

        TextView textView = (TextView) v;
        String mensagem = "Gasto selecionado: "
                + textView.getText();

        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show();
    }

}
