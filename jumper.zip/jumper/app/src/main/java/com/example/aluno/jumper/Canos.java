package com.example.aluno.jumper;

import android.graphics.Canvas;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Canos {
    private static final int QUANTIDADE_DE_CANOS = 5;
    private static final int DISTANCIA_ENTRE_CANOS = 350;
    private final List<Cano> canos = new ArrayList<Cano>();
    private Tela tela;
    private Pontuacao pontuacao;

    public Canos(Tela tela, Pontuacao pontuacao) {
        int posicaoInicial = 200;
        this.tela = tela;
        this.pontuacao = pontuacao;
        for (int i = 0; i < QUANTIDADE_DE_CANOS; i++) {
            posicaoInicial += DISTANCIA_ENTRE_CANOS;
            canos.add(new Cano(this.tela, posicaoInicial));
        }
    }

    public void desenhaNo(Canvas canvas) {
        for (Cano cano : canos)
            cano.desenhaNo(canvas);
    }

    public void move() {
        ListIterator<Cano> iterator = canos.listIterator();
        while (iterator.hasNext()) {
            Cano cano = (Cano) iterator.next();
            cano.move();
            if (cano.saiuDaTela()) {
                pontuacao.aumenta();
                iterator.remove();
                Cano outroCano =
                        new Cano(this.tela, getMaximo() + DISTANCIA_ENTRE_CANOS);
                iterator.add(outroCano);
            }
        }
    }

    private int getMaximo() {
        int maximo = 0;

        for (Cano cano : canos) {
            maximo = Math.max(cano.getPosicao(), maximo);
        }
        return maximo;
    }

    public boolean temColisaoCom(Passaro passaro) {
        for (Cano cano : canos) {
            if (cano.temColisaoHorizontalCom(passaro)
                    && cano.temColisaoVerticalCom(passaro)) {
                return true;
            }

        }
        return false;
    }
}
