package com.example.aluno.jumper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

public class Game extends SurfaceView implements Runnable, View.OnTouchListener {


    private Passaro passaro;
    private boolean isRunning = true;
    private Bitmap background;
    private Tela tela;
    private Canos canos;

    private Cano cano;
    private Pontuacao pontuacao;

    public Game(Context context) {
        super(context);
        inicializaElementos(context);
        setOnTouchListener(this);
    }

    private void inicializaElementos(Context context) {
        this.pontuacao = new Pontuacao();
        this.tela = new Tela(context);
        this.passaro = new Passaro(tela, context);
        this.canos = new Canos(tela, pontuacao);
        this.background = BitmapFactory.decodeResource(getResources(),
                R.drawable.background);

        this.background = Bitmap.createScaledBitmap(background,
                background.getWidth(), tela.getAltura(), false);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        passaro.pula();
        return false;
    }

    @Override
    public void run() {
        //Neste loop vamos gerenciar os elementos do Jumper.
        //lockCanvas e desenhos anteriores...
        while (isRunning) {
            if (!holder.getSurface().isValid()) continue;
            Canvas canvas = holder.lockCanvas();
            canvas.drawBitmap(background, 0, 0, null);
            passaro.desenhaNo(canvas);
            passaro.cai();
            canos.desenhaNo(canvas);
            canos.move();
            pontuacao.desenhaNo(canvas);
            if(new VerificadorDeColisao(passaro, canos).temColisao()) {
                new GameOver(tela).desenhaNo(canvas);
                isRunning = false;
            }
            holder.unlockCanvasAndPost(canvas);
        }
// Aqui vamos implementar o loop principal do nosso jogo!
    }

    public void cancela() {
        this.isRunning = false;
    }


    public void inicia() {
        this.isRunning = true;
    }


    private final SurfaceHolder holder = getHolder();


}

