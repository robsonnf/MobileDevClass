package com.example.aluno.jumper;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
private Game game;
    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_main);

        FrameLayout container = (FrameLayout) findViewById(R.id.container);
        game = new Game(this);
        container.addView(game);
    }
    @Override
    protected void onPause() {
        super.onPause();
        game.cancela();
    }
    @Override
    protected void onResume() {
        super.onResume();
        game.inicia();
        new Thread(game).start();
    }
}
