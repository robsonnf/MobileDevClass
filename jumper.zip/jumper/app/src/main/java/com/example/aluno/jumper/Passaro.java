package com.example.aluno.jumper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Passaro {
    private static final int X = 80;
    private static final int RAIO = 40;
    private int altura;
    private Tela tela;
    private Bitmap figura;

    public static int getX() {
        return X;
    }

    public int getAltura() {
        return altura;

    }

    public static int getRAIO() {
        return RAIO;
    }

    private static final Paint vermelho = Cores.getCorDoPassaro();


    public Passaro(Tela tela, Context context) {
        this.altura = 100;
        this.tela = tela;
        Bitmap bp = BitmapFactory.decodeResource(context.getResources(),
                R.drawable.passaro);
        figura = Bitmap.createScaledBitmap(bp, RAIO*2, RAIO*2 ,
                false);
    }


    public void desenhaNo(Canvas canvas){
       // canvas.drawCircle(X, altura, RAIO, vermelho);
        canvas.drawBitmap(figura, X-RAIO, altura-RAIO, null);
    }

    public void cai(){

        boolean chegouNoChao = altura + RAIO > tela.getAltura();
        if(!chegouNoChao) {
            altura += 5;
        }
    }

    public void pula() {

        if(altura > RAIO) {
            altura -= 80;
        }

    }

}
