package com.example.aluno.jumper;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Cano {
    private static final int TAMANHO_DO_CANO = 80;
    private static final int LARGURA_DO_CANO = 100;
    private int alturaDoCanoInferior;
    private int alturaDoCanoSuperior;
    private Tela tela;
    private int posicao;
    private static final Paint verde = Cores.getCorDoCano();

    public Cano(Tela tela, int posicao) {
        this.tela = tela;
        this.posicao = posicao;
        this.alturaDoCanoInferior =
                tela.getAltura() - TAMANHO_DO_CANO - valorAleatorio();
        this.alturaDoCanoSuperior = 0 + TAMANHO_DO_CANO +  valorAleatorio();
    }

    public void desenhaNo(Canvas canvas) {
        desenhaCanoSuperiorNo(canvas);
        desenhaCanoInferiorNo(canvas);
    }

    private void desenhaCanoInferiorNo(Canvas canvas) {
        canvas.drawRect(posicao, alturaDoCanoInferior,
                posicao + LARGURA_DO_CANO, tela.getAltura(), verde);
    }
    private void desenhaCanoSuperiorNo(Canvas canvas){
        canvas.drawRect(posicao, 0, posicao + LARGURA_DO_CANO,
                alturaDoCanoSuperior, verde);
}

    private int valorAleatorio() {
        return (int) (Math.random() * 250);
    }

    public void move() {

        posicao -= 5;
    }

    public boolean saiuDaTela() {
        return posicao + LARGURA_DO_CANO < 0;
    }

    public int getPosicao() {
        return posicao;
    }

    public boolean temColisaoVerticalCom(Passaro passaro) {
        return passaro.getAltura() -
                passaro.getRAIO() < this.alturaDoCanoSuperior
                || passaro.getAltura() + passaro.getRAIO() >
                this.alturaDoCanoInferior;
    }

    public boolean temColisaoHorizontalCom(Passaro passaro) {
        return this.posicao - passaro.getX() < passaro.getRAIO();
    }

}
