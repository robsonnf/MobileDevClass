package com.example.aluno.endereco;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends Activity {

    private AppDAO dao;
    private Spinner spUnidade;
    private Spinner spMunicipio;
    private Unidade ufSelecionada;
    private ArrayAdapter<Municipio> municipioAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spUnidade = (Spinner) findViewById(R.id.sp_unidade);
        spMunicipio = (Spinner) findViewById(R.id.sp_municipio);

        dao = new AppDAO(this);

        ArrayAdapter<Unidade> unidadeAdapter = new ArrayAdapter<Unidade>
                (this, android.R.layout.simple_spinner_dropdown_item,
                 dao.listarUnidades());

        spUnidade.setAdapter(unidadeAdapter);

        ufSelecionada = (Unidade) spUnidade.getSelectedItem();
        municipioAdapter = new ArrayAdapter<Municipio>
                (this, android.R.layout.simple_spinner_dropdown_item,
                dao.listarMunicipios(ufSelecionada));

        spMunicipio.setAdapter(municipioAdapter);

        spUnidade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                ufSelecionada = (Unidade) spUnidade.getSelectedItem();
                municipioAdapter = new ArrayAdapter<Municipio>
                        (getApplicationContext(), android.R.layout.simple_spinner_dropdown_item,
                                dao.listarMunicipios(ufSelecionada));

                spMunicipio.setAdapter(municipioAdapter);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




    }

    @Override
    protected void onDestroy(){
        dao.close();
        super.onDestroy();
    }
}
