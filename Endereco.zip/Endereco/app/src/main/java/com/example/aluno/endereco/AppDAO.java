package com.example.aluno.endereco;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class AppDAO {
    private DataBaseHelper helper;
    private SQLiteDatabase db;

    public AppDAO(Context context){
        helper = new DataBaseHelper(context);
    }

    public void close(){
        helper.close();
    }

    public SQLiteDatabase getRDb(){
        if (db == null){
            db = helper.getReadableDatabase();
        }

        return db;
    }

    public List<Unidade> listarUnidades() {
        Cursor cursor = getRDb().query(DataBaseHelper.UndHelper.TABELA,
                DataBaseHelper.UndHelper.COLUNAS,
                null, null, null, null, null);

        List<Unidade> unidades = new ArrayList<Unidade>();
        while (cursor.moveToNext()){
            Unidade unidade = criarUnidade(cursor);
            unidades.add(unidade);
        }

        cursor.close();
        return unidades;
    }

    public List<Municipio> listarMunicipios(Unidade unidade){
        List<Municipio> municipios = new ArrayList<Municipio>();

        String clausulaWhere = "unidade_id = ?";
        String[] valoresWhere = new String[]{String.valueOf(unidade.getId())};

        Cursor cursor = getRDb().query(DataBaseHelper.MunHelper.TABELA,
                DataBaseHelper.MunHelper.COLUNAS,
                clausulaWhere, valoresWhere, null, null, null);

        while(cursor.moveToNext()){
            Municipio municipio = criarMunicipio(cursor, unidade);
            municipios.add(municipio);
        }

        cursor.close();
        return municipios;
    }

    private Municipio criarMunicipio(Cursor cursor, Unidade unidade) {
        Municipio municipio = new Municipio(
        cursor.getInt(cursor.getColumnIndex(DataBaseHelper.MunHelper._ID)),
        cursor.getString(cursor.getColumnIndex(DataBaseHelper.MunHelper.NOME)),
        unidade);

        return municipio;
    }


    private Unidade criarUnidade(Cursor cursor){
        Unidade unidade = new Unidade(
        cursor.getInt(cursor.getColumnIndex(DataBaseHelper.UndHelper._ID)),
        cursor.getString(cursor.getColumnIndex(DataBaseHelper.UndHelper.SIGLA)),
        cursor.getString(cursor.getColumnIndex(DataBaseHelper.UndHelper.NOME)));

        return unidade;
    }
}
