package com.example.aluno.endereco;

public class Municipio {
    private int id;
    private String nome;
    private Unidade unidade;

    public Municipio() {
    }

    public Municipio(int id, String nome, Unidade unidade) {
        this.id = id;
        this.nome = nome;
        this.unidade = unidade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Unidade getUnidade() {
        return unidade;
    }

    public void setUnidade(Unidade unidade) {
        this.unidade = unidade;
    }

    @Override
    public String toString() {
        return nome;
    }
}
