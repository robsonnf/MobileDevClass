package com.example.aluno.endereco;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final String BANCO_DADOS = "BD_Endereco";
    private static final int VERSAO = 1;

    public static class UndHelper{
        public static final String TABELA = "unidade";
        public static final String _ID = "_id";
        public static final String SIGLA = "sigla";
        public static final String NOME = "nome";

        public static final String[] COLUNAS =
                new String[]{_ID, SIGLA, NOME};
    }

    public static class MunHelper{
        public static final String TABELA = "municipio";
        public static final String _ID = "_id";
        public static final String NOME = "nome";
        public static final String UNIDADE_ID = "unidade_id";

        public static final String[] COLUNAS =
                new String[]{_ID, NOME, UNIDADE_ID};
    }

    public DataBaseHelper(Context context) {
        super(context, BANCO_DADOS, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + UndHelper.TABELA + " (" +
        UndHelper._ID + " INTEGER PRIMARY KEY, " +
        UndHelper.SIGLA + " TEXT, " + UndHelper.NOME +
        " TEXT);");

        db.execSQL("CREATE TABLE municipio (_id INTEGER PRIMARY KEY," +
                "nome TEXT, unidade_id INTEGER, " +
                "FOREIGN KEY (unidade_id) REFERENCES unidade (_id));");

        db.execSQL("INSERT INTO " + UndHelper.TABELA + " (" + UndHelper.SIGLA +
        ", " + UndHelper.NOME + ") VALUES ('RS', 'Rio Grande do Sul')," +
                "('SC', 'Santa Catarina'),('SP', 'São Paulo')," +
                "('PR', 'Paraná');");

        db.execSQL("INSERT INTO municipio (nome, unidade_id) " +
                "VALUES ('Porto Alegre', 1), ('Canoas', 1), ('Alvorada', 1)," +
                "('Florianópolis', 2), ('Blumenau', 2), ('Camboriu', 2)," +
                "('São Paulo', 3), ('Santos', 3), ('Guarulhos', 3)," +
                "('Curitiba', 4), ('Londrina', 4), ('Foz do Iguaçu', 4)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE " + UndHelper.TABELA + ";");
        onCreate(db);
    }
}
