package com.example.aluno.listadecompras;

import android.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import java.text.NumberFormat;


public class MainActivity extends AppCompatActivity {

    private CheckBox chkArr, chkFei, chkFar, chkAcu, chkFra, chkVel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chkArr = (CheckBox) findViewById(R.id.chkArroz);
        chkFei = (CheckBox) findViewById(R.id.chkFeijao);
        chkFar = (CheckBox) findViewById(R.id.chkFarinha);
        chkAcu = (CheckBox) findViewById(R.id.chkAcucar);
        chkFra = (CheckBox) findViewById(R.id.chkFrango);
        chkVel = (CheckBox) findViewById(R.id.chkVelho);

    }


    public void calcular (View v){

        double total = 0;

        if (chkArr.isChecked()) {
            total += 3.2;
        }
        if (chkFei.isChecked()) {
            total += 6.15;
        }
        if (chkFar.isChecked()) {
            total += 4.7;
        }
        if (chkAcu.isChecked()) {
            total += 5.3;
        }
        if (chkFra.isChecked()) {
            total += 11.45;
        }
        if (chkVel.isChecked()) {
            total += 8.9;
        }

        NumberFormat nf = NumberFormat.getCurrencyInstance();

        AlertDialog.Builder dialogo = new
                AlertDialog.Builder(MainActivity.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage("Valor total da compra: R$   "
                           + nf.format(total));
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }
}








//String.valueOf(total));
